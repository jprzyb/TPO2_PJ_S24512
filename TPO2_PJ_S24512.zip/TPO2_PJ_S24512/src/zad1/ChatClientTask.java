/**
 *
 *  @author Przybylski Jakub S24512
 *
 */

package zad1;


public class ChatClientTask {
}
